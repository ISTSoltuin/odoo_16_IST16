# -*- coding: utf-8 -*-

from . import artista
from . import selo
from . import genero_musical