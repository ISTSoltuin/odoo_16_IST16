## Module <odoo_website_helpdesk>

#### 01.09.2023
#### Version 16.0.1.0.0
#### ADD

- Initial commit for Website Helpdesk Support Ticket

#### 28.11.2023
#### Version 16.0.1.0.1
#### FIX

- Updated the End date when changed the stage to Closed
